package com.example.WebApplicationForPet.Service;


import com.example.WebApplicationForPet.Model.User;
import com.example.WebApplicationForPet.Repo.UserRepository;
import jakarta.transaction.Transactional;
import lombok.extern.flogger.Flogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Register new user
    public void registerUser(User user) {
        userRepository.save(user);
    }

    // Authenticate user
    public boolean loginUser(String email, String password) {
        User user = userRepository.findByEmail(email);

        System.out.println("User found: " + user);
        System.out.println("Entered email: " + email);
        System.out.println("Entered password: " + password);

        if (user != null && user.getPassword().equals(password)) {
            System.out.println("Login successful!");
            return true;
        }

        System.out.println("Login failed: Incorrect email or password.");
        return false;
    }
    @Transactional
    public int increaseUserCoins(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setCoins(user.getCoins() + 2); // Increase by 2
        userRepository.save(user);

        return user.getCoins();
    }
}
