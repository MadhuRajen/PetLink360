package com.example.WebApplicationForPet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebApplicationForPetApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebApplicationForPetApplication.class, args);
	}

}
