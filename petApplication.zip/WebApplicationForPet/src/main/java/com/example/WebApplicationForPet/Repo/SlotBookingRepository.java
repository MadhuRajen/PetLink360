package com.example.WebApplicationForPet.Repo;


import com.example.WebApplicationForPet.Model.SlotBooking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SlotBookingRepository extends JpaRepository<SlotBooking, Long> {
    List<SlotBooking> findByHospitalName(String hospitalName);
    List<SlotBooking> findByUserPhoneNumber(String userPhoneNumber);

}
