package com.example.WebApplicationForPet.Controller;


import com.example.WebApplicationForPet.Model.LocationResponse;
import com.example.WebApplicationForPet.Service.NominatimService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/locations")

public class LocationController {

    @Autowired
    private NominatimService nominatimService;

    @GetMapping("/search")
    public ResponseEntity<?> searchLocations(@RequestParam String location, @RequestParam String type) {
        if (!type.equalsIgnoreCase("veterinary") && !type.equalsIgnoreCase("pharmacy")) {
            return ResponseEntity.badRequest().body("❌ Invalid type! Use 'veterinary' or 'pharmacy'.");
        }
        List<LocationResponse> places = nominatimService.searchPlaces(location, type);
        if (places.isEmpty()) {
            return ResponseEntity.status(404).body("❌ No " + type + " found in " + location);
        }
        return ResponseEntity.ok(places);
    }
}
