package com.example.WebApplicationForPet.Service;


import com.example.WebApplicationForPet.Model.SlotBooking;
import com.example.WebApplicationForPet.Repo.SlotBookingRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
public class SlotBookingService {

    private final SlotBookingRepository bookingRepository;
    private final SmsService smsService;

    public SlotBookingService(SlotBookingRepository bookingRepository, SmsService smsService) {
        this.bookingRepository = bookingRepository;
        this.smsService = smsService;
    }

    public SlotBooking bookSlot(String userName, String userPhoneNumber, String hospitalName, LocalDate bookingDate, LocalTime bookingTime,String petName) {
        SlotBooking slot = new SlotBooking();
        slot.setUserName(userName);
        slot.setUserPhoneNumber(userPhoneNumber);
        slot.setHospitalName(hospitalName);
        slot.setBookingDate(bookingDate);
        slot.setBookingTime(bookingTime);
        slot.setPetName(petName);
        SlotBooking savedSlot = bookingRepository.save(slot);

        if (savedSlot.getId() != null) {
            String message = "📢 Hello " + userName + ", your slot has been booked at " + hospitalName + ". Thank you!";
            smsService.sendSms(userPhoneNumber, message);
        }
        return savedSlot;
    }

    public List<SlotBooking> getBookingsByHospital(String hospitalName) {
        return bookingRepository.findByHospitalName(hospitalName);
    }

    public List<SlotBooking> getBookingsByUser(String userPhoneNumber) {
        return bookingRepository.findByUserPhoneNumber(userPhoneNumber);
    }
}
