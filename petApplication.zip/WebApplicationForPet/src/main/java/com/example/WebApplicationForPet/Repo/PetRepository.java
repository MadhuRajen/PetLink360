package com.example.WebApplicationForPet.Repo;

import com.example.WebApplicationForPet.Model.Pet;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PetRepository extends JpaRepository<Pet,Long> {
}
