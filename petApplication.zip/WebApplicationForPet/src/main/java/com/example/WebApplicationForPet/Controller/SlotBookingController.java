package com.example.WebApplicationForPet.Controller;


import com.example.WebApplicationForPet.Model.SlotBooking;
import com.example.WebApplicationForPet.Service.SlotBookingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/slots")
@CrossOrigin(origins = "http://localhost:3000")
public class SlotBookingController {

    private final SlotBookingService bookingService;

    public SlotBookingController(SlotBookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping("/book")
    public ResponseEntity<?> bookSlot(@RequestBody SlotBooking vo) {

        SlotBooking booking = bookingService.bookSlot(vo.getUserName(), vo.getUserPhoneNumber(), vo.getHospitalName(), vo.getBookingDate(),vo.getBookingTime(),vo.getPetName());

        if (booking != null) {
            return ResponseEntity.ok("✅ Slot booked successfully at " + vo.getHospitalName() + " for " + vo.getUserName()+" on "+vo.getBookingDate()+" at "+vo.getBookingTime());
        } else {
            return ResponseEntity.badRequest().body("❌ Booking failed. Try again.");
        }
    }

    @GetMapping("/hospital/{hospitalName}")
    public ResponseEntity<List<SlotBooking>> getBookingsByHospital(@PathVariable String hospitalName) {
        return ResponseEntity.ok(bookingService.getBookingsByHospital(hospitalName));
    }

    @GetMapping("/user/{phoneNumber}")
    public ResponseEntity<List<SlotBooking>> getBookingsByUser(@PathVariable String phoneNumber) {
        return ResponseEntity.ok(bookingService.getBookingsByUser(phoneNumber));
    }
}
