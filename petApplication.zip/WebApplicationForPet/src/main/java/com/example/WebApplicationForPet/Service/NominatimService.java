package com.example.WebApplicationForPet.Service;

import com.example.WebApplicationForPet.Model.LocationResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;


@Service
public class NominatimService {

    private static final String NOMINATIM_URL = "https://nominatim.openstreetmap.org/search";

    public List<LocationResponse> searchPlaces(String city, String type) {
        try {
            // Ensure correct query for veterinary hospitals or pharmacies
            String queryType = type.equalsIgnoreCase("veterinary") ? "veterinary" : "pharmacy";

            // Build API request URL
            String query = String.format("%s?q=%s+in+%s&format=json&addressdetails=1&limit=15",
                    NOMINATIM_URL, queryType, city);

            RestTemplate restTemplate = new RestTemplate();
            List<Map<String, Object>> response = restTemplate.getForObject(query, List.class);

            // Extract and return correct data
            List<LocationResponse> locations = new ArrayList<>();
            if (response != null) {
                for (Map<String, Object> place : response) {
                    String name = (String) place.getOrDefault("display_name", "Unknown");
                    String category = (String) place.getOrDefault("class", "unknown");
                    double lat = Double.parseDouble((String) place.getOrDefault("lat", "0.0"));
                    double lon = Double.parseDouble((String) place.getOrDefault("lon", "0.0"));

                    // Get address if available
                    Map<String, Object> addressDetails = (Map<String, Object>) place.get("address");
                    String address = (addressDetails != null) ? (String) addressDetails.getOrDefault("road", "Address not available") : "Address not available";

                    // Only include valid locations
                    if (!name.equals("Unknown") && lat != 0.0 && lon != 0.0 && category.equalsIgnoreCase("amenity")) {
                        locations.add(new LocationResponse(name, type, lat, lon, address));
                    }
                }
            }
            return locations;
        } catch (Exception e) {
            System.err.println("❌ Error fetching places from Nominatim API: " + e.getMessage());
            return Collections.emptyList();
        }
    }
}