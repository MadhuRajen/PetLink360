package com.example.WebApplicationForPet.Controller;

import com.example.WebApplicationForPet.Model.Pet;
import com.example.WebApplicationForPet.Model.SlotBooking;
import com.example.WebApplicationForPet.Model.User;
import com.example.WebApplicationForPet.Repo.PetRepository;
import com.example.WebApplicationForPet.Repo.SlotBookingRepository;
import com.example.WebApplicationForPet.Repo.UserRepository;
import com.example.WebApplicationForPet.Service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Controller
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private HttpSession session;
    @Autowired
    PetRepository petRepository;
    @Autowired
    SlotBookingRepository slotBookingRepository;

    @GetMapping("/signup")
    public String showSignupForm(Model model) {
        model.addAttribute("user", new User());
        return "signup";
    }
    @GetMapping("/savePetDetails")
    public String showpetForm(Model model) {
        model.addAttribute("pet", new Pet());
        return "Pet Profile";
    }

    @PostMapping("/signup")
    public String registerUser(@ModelAttribute User user) {
        userService.registerUser(user);
        return "redirect:/login";
    }


    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String email, @RequestParam String password, HttpSession session, Model model) {
        User user = userRepository.findByEmail(email);

        if (user != null && user.getPassword().equals(password)) {  // (Use password hashing in production)
            session.setAttribute("userEmail", email); // Store email in session
            System.out.println("Login successful! Session set for: " + email);
            return "redirect:/home"; // Redirect to account page after login
        } else {
            model.addAttribute("error", "Invalid email or password");
            return "login"; // Show login page again if authentication fails
        }
    }




    @GetMapping("/index.html")
    public String showHomePages() {
        return "home";
    }

    @GetMapping("/home")
    public String showHomePage() {
        return "home";
    }

    // About Page
    @GetMapping("/about.html")
    public String showAboutPage() {
        return "about";
    }

    // Services Page
    @GetMapping("/service.html")
    public String showServicePage() {
        return "service";
    }

    // Breeding Page
    @GetMapping("/Breeding.html")
    public String showBreedingPage() {
        return "Breeding";
    }

    // Support Strays Page
    @GetMapping("/Support Strays.html")
    public String showSupportStraysPage() {
        return "Support Strays";
    }

    // Chatbot Page
    @GetMapping("/chatbot.html")
    public String showChatbotPage() {
        return "chatbot";
    }


    @GetMapping("/my-account")
    public String showMyAccountPage(HttpSession session, Model model) {
        String userEmail = (String) session.getAttribute("userEmail");

        if (userEmail == null) {
            return "redirect:/login";
        }

        User user = userRepository.findByEmail(userEmail);
        if (user == null) {
            throw new RuntimeException("User not found!");
        }

        List<Pet> pets = user.getPets(); // Fetch user's pets

        model.addAttribute("user", user);
        model.addAttribute("pets", pets); // Pass pet list to UI

        return "MyAccount"; // Load MyAccount.html
    }


    @PostMapping("/savePetDetails")
    public String savePetDetails(@RequestParam(required = false) String email,
                                 @RequestParam String petName,
                                 @RequestParam String type,
                                 @RequestParam String breed,
                                 @RequestParam int age,
                                 @RequestParam String healthStatus){


        // Check if email is missing
        if (email == null || email.isEmpty()) {
            throw new RuntimeException("Email is required!");
        }

        // Find user by email
        User user = userRepository.findByEmail(email);
        if (user == null) {
            throw new RuntimeException("User not found!");
        }

        // Create and save pet
        Pet pet = new Pet();
        pet.setPetName(petName);
        pet.setType(type);
        pet.setBreed(breed);
        pet.setAge(age);
        pet.setUser(user);
        pet.setHealthStatus(healthStatus);

        petRepository.save(pet);

        return "redirect:/my-account?email=" + email;
    }

    // Pet Profile Page
    @GetMapping("/Pet Profile.html")
    public String showPetProfilePage() {
        return "Pet Profile";
    }

    // Coins Page
    @GetMapping("/Coins.html")
    public String showCoinsPage() {
        return "Coins";
    }


    @GetMapping("/Dashboard.html")
    public String showDashboardPage() {
        return "dashboard";
    }


    @GetMapping("/dashboard")
    public String showDashboard(HttpSession session, Model model) {
        String userEmail = (String) session.getAttribute("userEmail");

        if (userEmail == null) {
            return "redirect:/login"; // Redirect if user is not logged in
        }

        User user = userRepository.findByEmail(userEmail);

        if (user == null) {
            throw new RuntimeException("User not found!");
        }

        List<Pet> pets = user.getPets(); // Fetch pets associated with the user

        List<SlotBooking> appointments = slotBookingRepository.findByUserPhoneNumber(user.getPhoneNumber());
        System.out.println("apointments---"+appointments);
        System.out.println("phoneNumber-----"+user.getPhoneNumber());
        model.addAttribute("user", user);
        model.addAttribute("pets", pets);
        model.addAttribute("appointments", appointments);
        return "dashboard"; // Load the Thymeleaf template for the dashboard
    }

    @PostMapping("/update-user")
    public String updateUser(@ModelAttribute User updatedUser, HttpSession session, Model model) {
        String userEmail = (String) session.getAttribute("userEmail");

        if (userEmail == null) {
            return "redirect:/login"; // Redirect if user is not logged in
        }

        User user = userRepository.findByEmail(userEmail);
        if (user == null) {
            throw new RuntimeException("User not found!");
        }

        // ✅ Ensure Only Non-Empty Fields Are Updated
        if (updatedUser.getName() != null) {
            user.setName(updatedUser.getName());
        }
        if (updatedUser.getPhoneNumber() != null && !updatedUser.getPhoneNumber().isEmpty()) {
            user.setPhoneNumber(updatedUser.getPhoneNumber());
        }

        userRepository.save(user);

        // ✅ Pass updated user back to model
        model.addAttribute("user", user);
        return "redirect:/my-account";
    }

    @GetMapping("/increaseCoins")
    public ResponseEntity<Map<String, Integer>> increaseCoins(HttpSession session) {
        String userEmail = (String) session.getAttribute("userEmail");

        if (userEmail == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Collections.singletonMap("coins", 0));
        }

        User user = userRepository.findByEmail(userEmail);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Collections.singletonMap("coins", 0));
        }

        user.setCoins(user.getCoins() + 2);
        userRepository.save(user);

        return ResponseEntity.ok(Collections.singletonMap("coins", user.getCoins()));
    }
    @GetMapping("/getCoins")
    public ResponseEntity<Map<String, Integer>> getCoins(HttpSession session) {
        String userEmail = (String) session.getAttribute("userEmail");

        if (userEmail == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Collections.singletonMap("coins", 0));
        }

        User user = userRepository.findByEmail(userEmail);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Collections.singletonMap("coins", 0));
        }

        return ResponseEntity.ok(Collections.singletonMap("coins", user.getCoins()));
    }


}


